-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 29, 2026 at 04:08 AM
-- Server version: 8.0.45-0ubuntu0.22.04.1
-- PHP Version: 8.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `magnum_sales`
--

-- --------------------------------------------------------

--
-- Table structure for table `counter_id`
--

CREATE TABLE `counter_id` (
  `property_id` int NOT NULL,
  `counter_name` varchar(255) NOT NULL,
  `ym` varchar(6) NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `counter` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE `currency` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `property_id` bigint UNSIGNED DEFAULT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` bigint NOT NULL,
  `category_id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `npwp` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL,
  `notes` text,
  `sales_id` bigint DEFAULT NULL,
  `property_id` int NOT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `users_id` int NOT NULL,
  `allow_to_vendor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '1',
  `acc_id` int DEFAULT NULL,
  `begin_date` date DEFAULT NULL,
  `balance` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_asli`
--

CREATE TABLE `customer_asli` (
  `id` bigint NOT NULL,
  `category_id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL,
  `notes` text,
  `sales_id` bigint DEFAULT NULL,
  `property_id` int NOT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `users_id` int NOT NULL,
  `allow_to_vendor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_category`
--

CREATE TABLE `customer_category` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `property_id` int UNSIGNED DEFAULT '1',
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_contact`
--

CREATE TABLE `customer_contact` (
  `id` int NOT NULL,
  `customer_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `followup_notification`
-- (See below for the actual view)
--
CREATE TABLE `followup_notification` (
`id` varchar(15)
,`quotation_id` varchar(255)
,`quotation_date` date
,`customer_name` varchar(255)
,`subject` varchar(255)
,`last_followup` date
,`total` varchar(63)
,`email` varchar(255)
,`user_name` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_pivot_cancel_quotation`
-- (See below for the actual view)
--
CREATE TABLE `get_pivot_cancel_quotation` (
`January` double
,`February` double
,`March` double
,`April` double
,`May` double
,`June` double
,`July` double
,`August` double
,`September` double
,`October` double
,`November` double
,`December` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_pivot_decline_quotation`
-- (See below for the actual view)
--
CREATE TABLE `get_pivot_decline_quotation` (
`January` double
,`February` double
,`March` double
,`April` double
,`May` double
,`June` double
,`July` double
,`August` double
,`September` double
,`October` double
,`November` double
,`December` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_pivot_followup_quotation`
-- (See below for the actual view)
--
CREATE TABLE `get_pivot_followup_quotation` (
`January` double
,`Febuary` double
,`March` double
,`April` double
,`May` double
,`June` double
,`July` double
,`August` double
,`September` double
,`October` double
,`November` double
,`December` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_pivot_po_quotation`
-- (See below for the actual view)
--
CREATE TABLE `get_pivot_po_quotation` (
`January` double
,`Febuary` double
,`March` double
,`April` double
,`May` double
,`June` double
,`July` double
,`August` double
,`September` double
,`October` double
,`November` double
,`December` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_quotation_year_to_date`
-- (See below for the actual view)
--
CREATE TABLE `get_quotation_year_to_date` (
`name` varchar(255)
,`total` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_sales_project_retail`
-- (See below for the actual view)
--
CREATE TABLE `get_sales_project_retail` (
`quotation_type` int
,`total` double
);

-- --------------------------------------------------------

--
-- Table structure for table `master_departements`
--

CREATE TABLE `master_departements` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `property_id` bigint UNSIGNED DEFAULT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_properties`
--

CREATE TABLE `master_properties` (
  `id` bigint NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `address` text,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_table_access`
--

CREATE TABLE `master_table_access` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_term`
--

CREATE TABLE `payment_term` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `day` int DEFAULT NULL,
  `property_id` int DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  `user_update` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `po_detail`
--

CREATE TABLE `po_detail` (
  `id` varchar(15) NOT NULL,
  `line` int NOT NULL,
  `no` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `part_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `descriptions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `qty` double DEFAULT NULL,
  `unit_id` int DEFAULT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL,
  `hpp` double DEFAULT NULL,
  `hpp_total` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `po_master`
--

CREATE TABLE `po_master` (
  `property_id` int NOT NULL,
  `id` varchar(15) NOT NULL,
  `quot_id` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `rev_id` int NOT NULL,
  `po_no` varchar(255) DEFAULT NULL,
  `po_date` date NOT NULL,
  `customer_id` int NOT NULL,
  `contact_id` int DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `total` double DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `tax_value` double DEFAULT '0',
  `pph` int DEFAULT NULL,
  `pph_value` double DEFAULT '0',
  `disc` double DEFAULT NULL,
  `grand_total` double DEFAULT NULL,
  `payment_term` int DEFAULT NULL,
  `notes` text,
  `status` int NOT NULL DEFAULT '1',
  `user_created` int DEFAULT NULL,
  `user_update` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `level` int DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `project_start` date DEFAULT NULL,
  `project_end` date DEFAULT NULL,
  `site_manager` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `barcode` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` int DEFAULT '0',
  `category_id` int DEFAULT NULL,
  `vendor_id` int DEFAULT NULL,
  `unit_id` int DEFAULT NULL,
  `currency_buy` int DEFAULT NULL,
  `buy_price` float DEFAULT '0',
  `currency_sell` int DEFAULT '0',
  `sell_price` float DEFAULT '0',
  `min` float DEFAULT '0',
  `max` float DEFAULT '0',
  `start_stock` float DEFAULT '0',
  `start_value` float DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_stock` float DEFAULT '0',
  `end_value` float DEFAULT '0',
  `last_buy_price` float DEFAULT '0',
  `enable` tinyint(1) DEFAULT '1',
  `allow_buy` tinyint(1) DEFAULT '1',
  `allow_sell` tinyint(1) DEFAULT '1',
  `descriptions` text,
  `property_id` int NOT NULL,
  `user_created` int NOT NULL,
  `user_update` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_bundle_items`
--

CREATE TABLE `product_bundle_items` (
  `id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `qty` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `property_id` bigint UNSIGNED DEFAULT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_unit_items`
--

CREATE TABLE `product_unit_items` (
  `product_id` bigint NOT NULL,
  `line` int NOT NULL,
  `unit_id` int DEFAULT NULL,
  `value` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_level`
--

CREATE TABLE `project_level` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_priority`
--

CREATE TABLE `project_priority` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `id` varchar(12) NOT NULL,
  `date` date NOT NULL,
  `vendor_id` int NOT NULL,
  `payment_term` int DEFAULT NULL,
  `shipvia` int DEFAULT NULL,
  `currency_buy` int DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `shipping` double DEFAULT NULL,
  `other` double DEFAULT NULL,
  `total` double DEFAULT NULL,
  `warehouse` int DEFAULT NULL,
  `property_id` int DEFAULT NULL,
  `notes` text,
  `user_created` int DEFAULT NULL,
  `user_update` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_item`
--

CREATE TABLE `purchase_item` (
  `id` varchar(12) NOT NULL,
  `line` int NOT NULL,
  `product_id` int DEFAULT NULL,
  `unit_id` int DEFAULT NULL,
  `qtr` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `total` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotation`
--

CREATE TABLE `quotation` (
  `property_id` int NOT NULL,
  `id` varchar(15) NOT NULL,
  `quotation_type` int NOT NULL DEFAULT '1',
  `quotation_id` varchar(255) NOT NULL,
  `quotation_date` date NOT NULL,
  `customer_id` int NOT NULL,
  `contact_id` int DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `total` double DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `tax_value` double DEFAULT '0',
  `pph` double DEFAULT '0',
  `pph_value` double DEFAULT '0',
  `disc` double DEFAULT NULL,
  `grand_total` double DEFAULT NULL,
  `hpp_total` double DEFAULT NULL,
  `profit` double DEFAULT NULL,
  `margin` double DEFAULT NULL,
  `profit_value` double DEFAULT NULL,
  `payment_term` int DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `commision` double DEFAULT NULL,
  `notes` text,
  `status` int NOT NULL DEFAULT '1',
  `status_review` text,
  `progress` int NOT NULL DEFAULT '2',
  `followup_by` int DEFAULT NULL,
  `followup_date` date DEFAULT NULL,
  `next_followup` date NOT NULL,
  `folder` varchar(255) DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  `user_update` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notif` tinyint(1) NOT NULL DEFAULT '0',
  `level` int DEFAULT '0',
  `priority` int DEFAULT '0',
  `project_start` date DEFAULT NULL,
  `project_end` date DEFAULT NULL,
  `po_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `po_date` date DEFAULT NULL,
  `po_file` varchar(255) DEFAULT NULL,
  `po_assign_to` varchar(255) DEFAULT NULL,
  `sales_id` bigint UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotation_detail`
--

CREATE TABLE `quotation_detail` (
  `id` varchar(15) NOT NULL,
  `rev_id` int NOT NULL,
  `line` int NOT NULL,
  `no` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `part_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `product_type` int NOT NULL DEFAULT '1',
  `descriptions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `qty` double DEFAULT NULL,
  `unit_id` int DEFAULT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL,
  `other_cost` double NOT NULL DEFAULT '0',
  `hpp` double DEFAULT '0',
  `hpp_total` double DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotation_files`
--

CREATE TABLE `quotation_files` (
  `id` varchar(15) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotation_followup`
--

CREATE TABLE `quotation_followup` (
  `property_id` int NOT NULL,
  `id` varchar(15) NOT NULL,
  `line_id` int NOT NULL,
  `followup_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `followup_by` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `progress` int NOT NULL DEFAULT '2',
  `next_followup` datetime DEFAULT CURRENT_TIMESTAMP,
  `notes` text,
  `user_created` int DEFAULT NULL,
  `user_update` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `po_no` varchar(255) DEFAULT NULL,
  `po_date` date DEFAULT NULL,
  `po_file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Triggers `quotation_followup`
--
DELIMITER $$
CREATE TRIGGER `delete_quotation_status` AFTER DELETE ON `quotation_followup` FOR EACH ROW BEGIN
CALL update_quotation_status(OLD.id);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insert_quotation_status` AFTER INSERT ON `quotation_followup` FOR EACH ROW BEGIN
CALL update_quotation_status(NEW.id);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_quotation_status` AFTER UPDATE ON `quotation_followup` FOR EACH ROW BEGIN
CALL update_quotation_status(NEW.id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `quotation_master`
--

CREATE TABLE `quotation_master` (
  `id` varchar(15) NOT NULL,
  `rev_id` int NOT NULL,
  `quotation_date` date NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `total` double DEFAULT NULL,
  `disc` double DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `tax_value` double DEFAULT '0',
  `pph` double DEFAULT '0',
  `pph_value` double DEFAULT '0',
  `grand_total` double DEFAULT NULL,
  `hpp_total` double DEFAULT NULL,
  `profit` double NOT NULL DEFAULT '0',
  `margin` double DEFAULT NULL,
  `profit_value` double DEFAULT NULL,
  `payment_term` int DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `commision` double DEFAULT NULL,
  `notes` text,
  `user_created` int DEFAULT NULL,
  `user_update` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `default_quot` tinyint(1) DEFAULT '0',
  `level` int DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `project_start` date DEFAULT NULL,
  `project_end` date DEFAULT NULL,
  `po_no` varchar(255) DEFAULT NULL,
  `po_date` date DEFAULT NULL,
  `po_file` varchar(255) DEFAULT NULL,
  `po_assign_to` varchar(255) DEFAULT NULL,
  `sales_id` bigint UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotation_pivot`
--

CREATE TABLE `quotation_pivot` (
  `property_id` int NOT NULL,
  `id` varchar(15) NOT NULL,
  `status` int NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotation_progress`
--

CREATE TABLE `quotation_progress` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `progress` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotation_status`
--

CREATE TABLE `quotation_status` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotation_subdetail`
--

CREATE TABLE `quotation_subdetail` (
  `id` varchar(15) NOT NULL,
  `rev_id` int NOT NULL,
  `line` int NOT NULL,
  `subline` int NOT NULL,
  `no` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `part_no` varchar(255) DEFAULT NULL,
  `product_type` int NOT NULL DEFAULT '1',
  `descriptions` text,
  `qty` double DEFAULT NULL,
  `unit_id` int DEFAULT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL,
  `other_cost` double NOT NULL DEFAULT '0',
  `hpp` double DEFAULT '0',
  `hpp_total` double DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotation_target`
--

CREATE TABLE `quotation_target` (
  `id` bigint UNSIGNED NOT NULL,
  `year` int NOT NULL,
  `property_id` bigint UNSIGNED DEFAULT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reminder`
--

CREATE TABLE `reminder` (
  `id` bigint NOT NULL,
  `property_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `reminder_type` int NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `notes` text NOT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reminder_participant`
--

CREATE TABLE `reminder_participant` (
  `id` int NOT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reminder_type`
--

CREATE TABLE `reminder_type` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int NOT NULL,
  `property_id` int NOT NULL,
  `code` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `setting_bak1`
--

CREATE TABLE `setting_bak1` (
  `id` int NOT NULL,
  `property_id` int NOT NULL,
  `code` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL,
  `notes` text,
  `property_id` int NOT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `property_id` bigint UNSIGNED DEFAULT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `property_id` bigint UNSIGNED DEFAULT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_no` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_group_id` bigint DEFAULT NULL,
  `departement_id` bigint DEFAULT NULL,
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sign` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `property_id` bigint DEFAULT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT '1',
  `inisial` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_created` int NOT NULL,
  `user_update` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `user_before_delete` BEFORE DELETE ON `users` FOR EACH ROW DELETE FROM user_policies WHERE user_id = OLD.id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `property_id` bigint UNSIGNED DEFAULT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Triggers `user_groups`
--
DELIMITER $$
CREATE TRIGGER `user_group_before_del` BEFORE DELETE ON `user_groups` FOR EACH ROW DELETE FROM user_group_policies WHERE group_id = OLD.id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_group_policies`
--

CREATE TABLE `user_group_policies` (
  `id` bigint NOT NULL,
  `group_id` bigint NOT NULL,
  `table_name` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `property_id` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_policies`
--

CREATE TABLE `user_policies` (
  `id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `table_name` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `property_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL,
  `notes` text,
  `property_id` int NOT NULL,
  `user_created` bigint UNSIGNED DEFAULT NULL,
  `user_update` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure for view `followup_notification`
--
DROP TABLE IF EXISTS `followup_notification`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `followup_notification`  AS SELECT `q`.`id` AS `id`, `q`.`quotation_id` AS `quotation_id`, `q`.`quotation_date` AS `quotation_date`, `c`.`name` AS `customer_name`, `q`.`subject` AS `subject`, `q`.`followup_date` AS `last_followup`, concat('Rp',format(`q`.`grand_total`,0)) AS `total`, `u`.`email` AS `email`, `u`.`name` AS `user_name` FROM ((`quotation` `q` left join `customer` `c` on((`q`.`customer_id` = `c`.`id`))) left join `users` `u` on((`q`.`user_created` = `u`.`id`))) WHERE ((`q`.`status` = 1) AND (`q`.`next_followup` <= curdate()) AND (year(`q`.`quotation_date`) >= 2024) AND (`u`.`enable` = 1)) ORDER BY `u`.`email` ASC, `q`.`quotation_date` ASC ;

-- --------------------------------------------------------

--
-- Structure for view `get_pivot_cancel_quotation`
--
DROP TABLE IF EXISTS `get_pivot_cancel_quotation`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_pivot_cancel_quotation`  AS SELECT sum(if((month(`q`.`quotation_date`) = 1),`q`.`grand_total`,0)) AS `January`, sum(if((month(`q`.`quotation_date`) = 2),`q`.`grand_total`,0)) AS `February`, sum(if((month(`q`.`quotation_date`) = 3),`q`.`grand_total`,0)) AS `March`, sum(if((month(`q`.`quotation_date`) = 4),`q`.`grand_total`,0)) AS `April`, sum(if((month(`q`.`quotation_date`) = 5),`q`.`grand_total`,0)) AS `May`, sum(if((month(`q`.`quotation_date`) = 6),`q`.`grand_total`,0)) AS `June`, sum(if((month(`q`.`quotation_date`) = 7),`q`.`grand_total`,0)) AS `July`, sum(if((month(`q`.`quotation_date`) = 8),`q`.`grand_total`,0)) AS `August`, sum(if((month(`q`.`quotation_date`) = 9),`q`.`grand_total`,0)) AS `September`, sum(if((month(`q`.`quotation_date`) = 10),`q`.`grand_total`,0)) AS `October`, sum(if((month(`q`.`quotation_date`) = 11),`q`.`grand_total`,0)) AS `November`, sum(if((month(`q`.`quotation_date`) = 12),`q`.`grand_total`,0)) AS `December` FROM `quotation` AS `q` WHERE ((`q`.`property_id` = 1) AND (`q`.`status` = 4) AND (year(`q`.`quotation_date`) = year(curdate()))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_pivot_decline_quotation`
--
DROP TABLE IF EXISTS `get_pivot_decline_quotation`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_pivot_decline_quotation`  AS SELECT sum(if((month(`q`.`quotation_date`) = 1),`q`.`grand_total`,0)) AS `January`, sum(if((month(`q`.`quotation_date`) = 2),`q`.`grand_total`,0)) AS `February`, sum(if((month(`q`.`quotation_date`) = 3),`q`.`grand_total`,0)) AS `March`, sum(if((month(`q`.`quotation_date`) = 4),`q`.`grand_total`,0)) AS `April`, sum(if((month(`q`.`quotation_date`) = 5),`q`.`grand_total`,0)) AS `May`, sum(if((month(`q`.`quotation_date`) = 6),`q`.`grand_total`,0)) AS `June`, sum(if((month(`q`.`quotation_date`) = 7),`q`.`grand_total`,0)) AS `July`, sum(if((month(`q`.`quotation_date`) = 8),`q`.`grand_total`,0)) AS `August`, sum(if((month(`q`.`quotation_date`) = 9),`q`.`grand_total`,0)) AS `September`, sum(if((month(`q`.`quotation_date`) = 10),`q`.`grand_total`,0)) AS `October`, sum(if((month(`q`.`quotation_date`) = 113),`q`.`grand_total`,0)) AS `November`, sum(if((month(`q`.`quotation_date`) = 12),`q`.`grand_total`,0)) AS `December` FROM `quotation` AS `q` WHERE ((`q`.`property_id` = 1) AND (`q`.`status` = 2) AND (year(`q`.`quotation_date`) = year(curdate()))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_pivot_followup_quotation`
--
DROP TABLE IF EXISTS `get_pivot_followup_quotation`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_pivot_followup_quotation`  AS SELECT sum(if((month(`q`.`quotation_date`) = 1),`q`.`grand_total`,0)) AS `January`, sum(if((month(`q`.`quotation_date`) = 2),`q`.`grand_total`,0)) AS `Febuary`, sum(if((month(`q`.`quotation_date`) = 3),`q`.`grand_total`,0)) AS `March`, sum(if((month(`q`.`quotation_date`) = 4),`q`.`grand_total`,0)) AS `April`, sum(if((month(`q`.`quotation_date`) = 5),`q`.`grand_total`,0)) AS `May`, sum(if((month(`q`.`quotation_date`) = 6),`q`.`grand_total`,0)) AS `June`, sum(if((month(`q`.`quotation_date`) = 7),`q`.`grand_total`,0)) AS `July`, sum(if((month(`q`.`quotation_date`) = 8),`q`.`grand_total`,0)) AS `August`, sum(if((month(`q`.`quotation_date`) = 9),`q`.`grand_total`,0)) AS `September`, sum(if((month(`q`.`quotation_date`) = 10),`q`.`grand_total`,0)) AS `October`, sum(if((month(`q`.`quotation_date`) = 11),`q`.`grand_total`,0)) AS `November`, sum(if((month(`q`.`quotation_date`) = 12),`q`.`grand_total`,0)) AS `December` FROM `quotation` AS `q` WHERE ((`q`.`property_id` = 1) AND (year(`q`.`quotation_date`) = year(curdate()))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_pivot_po_quotation`
--
DROP TABLE IF EXISTS `get_pivot_po_quotation`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_pivot_po_quotation`  AS SELECT sum(if((month(`q`.`quotation_date`) = 1),`q`.`grand_total`,0)) AS `January`, sum(if((month(`q`.`quotation_date`) = 2),`q`.`grand_total`,0)) AS `Febuary`, sum(if((month(`q`.`quotation_date`) = 3),`q`.`grand_total`,0)) AS `March`, sum(if((month(`q`.`quotation_date`) = 4),`q`.`grand_total`,0)) AS `April`, sum(if((month(`q`.`quotation_date`) = 5),`q`.`grand_total`,0)) AS `May`, sum(if((month(`q`.`quotation_date`) = 6),`q`.`grand_total`,0)) AS `June`, sum(if((month(`q`.`quotation_date`) = 7),`q`.`grand_total`,0)) AS `July`, sum(if((month(`q`.`quotation_date`) = 8),`q`.`grand_total`,0)) AS `August`, sum(if((month(`q`.`quotation_date`) = 9),`q`.`grand_total`,0)) AS `September`, sum(if((month(`q`.`quotation_date`) = 10),`q`.`grand_total`,0)) AS `October`, sum(if((month(`q`.`quotation_date`) = 11),`q`.`grand_total`,0)) AS `November`, sum(if((month(`q`.`quotation_date`) = 12),`q`.`grand_total`,0)) AS `December` FROM `quotation` AS `q` WHERE ((`q`.`property_id` = 1) AND (`q`.`status` = 3) AND (year(`q`.`quotation_date`) = year(curdate()))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_quotation_year_to_date`
--
DROP TABLE IF EXISTS `get_quotation_year_to_date`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_quotation_year_to_date`  AS SELECT `s`.`name` AS `name`, sum(`q1`.`grand_total`) AS `total` FROM (`quotation` `q1` left join `quotation_status` `s` on((`q1`.`status` = `s`.`id`))) WHERE (year(`q1`.`quotation_date`) = year(curdate())) GROUP BY `q1`.`status` ;

-- --------------------------------------------------------

--
-- Structure for view `get_sales_project_retail`
--
DROP TABLE IF EXISTS `get_sales_project_retail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_sales_project_retail`  AS SELECT `quotation`.`quotation_type` AS `quotation_type`, sum(`quotation`.`grand_total`) AS `total` FROM `quotation` WHERE ((`quotation`.`status` = 3) AND (year(`quotation`.`quotation_date`) = year(curdate()))) GROUP BY `quotation`.`quotation_type` ORDER BY `quotation`.`quotation_type` ASC ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `counter_id`
--
ALTER TABLE `counter_id`
  ADD PRIMARY KEY (`property_id`,`counter_name`,`ym`,`type`) USING BTREE;

--
-- Indexes for table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`) USING BTREE,
  ADD KEY `category_id` (`category_id`),
  ADD KEY `sales_id` (`sales_id`);

--
-- Indexes for table `customer_asli`
--
ALTER TABLE `customer_asli`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`) USING BTREE,
  ADD KEY `category_id` (`category_id`),
  ADD KEY `sales_id` (`sales_id`);

--
-- Indexes for table `customer_category`
--
ALTER TABLE `customer_category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `customer_contact`
--
ALTER TABLE `customer_contact`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cust_contact_name` (`customer_id`,`id`);

--
-- Indexes for table `master_departements`
--
ALTER TABLE `master_departements`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_property` (`name`,`property_id`);

--
-- Indexes for table `master_properties`
--
ALTER TABLE `master_properties`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`) USING BTREE,
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `master_table_access`
--
ALTER TABLE `master_table_access`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payment_term`
--
ALTER TABLE `payment_term`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `property_id` (`property_id`,`name`);

--
-- Indexes for table `po_detail`
--
ALTER TABLE `po_detail`
  ADD PRIMARY KEY (`id`,`line`) USING BTREE;

--
-- Indexes for table `po_master`
--
ALTER TABLE `po_master`
  ADD PRIMARY KEY (`property_id`,`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_bundle_items`
--
ALTER TABLE `product_bundle_items`
  ADD PRIMARY KEY (`id`,`product_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `product_unit_items`
--
ALTER TABLE `product_unit_items`
  ADD PRIMARY KEY (`product_id`,`line`);

--
-- Indexes for table `project_level`
--
ALTER TABLE `project_level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_priority`
--
ALTER TABLE `project_priority`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_item`
--
ALTER TABLE `purchase_item`
  ADD PRIMARY KEY (`id`,`line`);

--
-- Indexes for table `quotation`
--
ALTER TABLE `quotation`
  ADD PRIMARY KEY (`property_id`,`id`),
  ADD KEY `id` (`id`),
  ADD KEY `fromdate_todate` (`quotation_date`);

--
-- Indexes for table `quotation_detail`
--
ALTER TABLE `quotation_detail`
  ADD PRIMARY KEY (`rev_id`,`id`,`line`) USING BTREE;

--
-- Indexes for table `quotation_files`
--
ALTER TABLE `quotation_files`
  ADD UNIQUE KEY `id` (`id`,`file_name`);

--
-- Indexes for table `quotation_followup`
--
ALTER TABLE `quotation_followup`
  ADD PRIMARY KEY (`property_id`,`id`,`line_id`) USING BTREE,
  ADD KEY `id` (`id`);

--
-- Indexes for table `quotation_master`
--
ALTER TABLE `quotation_master`
  ADD PRIMARY KEY (`id`,`rev_id`) USING BTREE;

--
-- Indexes for table `quotation_pivot`
--
ALTER TABLE `quotation_pivot`
  ADD PRIMARY KEY (`property_id`,`id`,`status`);

--
-- Indexes for table `quotation_progress`
--
ALTER TABLE `quotation_progress`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotation_status`
--
ALTER TABLE `quotation_status`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `quotation_subdetail`
--
ALTER TABLE `quotation_subdetail`
  ADD PRIMARY KEY (`rev_id`,`id`,`line`,`subline`) USING BTREE;

--
-- Indexes for table `quotation_target`
--
ALTER TABLE `quotation_target`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reminder`
--
ALTER TABLE `reminder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reminder_participant`
--
ALTER TABLE `reminder_participant`
  ADD PRIMARY KEY (`id`,`user_id`);

--
-- Indexes for table `reminder_type`
--
ALTER TABLE `reminder_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_code` (`property_id`,`code`);

--
-- Indexes for table `setting_bak1`
--
ALTER TABLE `setting_bak1`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_code` (`property_id`,`code`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`) USING BTREE;

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`property_id`,`name`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_group_policies`
--
ALTER TABLE `user_group_policies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tblname` (`property_id`,`group_id`,`table_name`,`action`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `user_policies`
--
ALTER TABLE `user_policies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `currency`
--
ALTER TABLE `currency`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_asli`
--
ALTER TABLE `customer_asli`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_category`
--
ALTER TABLE `customer_category`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_contact`
--
ALTER TABLE `customer_contact`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_departements`
--
ALTER TABLE `master_departements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_properties`
--
ALTER TABLE `master_properties`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_table_access`
--
ALTER TABLE `master_table_access`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_term`
--
ALTER TABLE `payment_term`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_level`
--
ALTER TABLE `project_level`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_priority`
--
ALTER TABLE `project_priority`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quotation_progress`
--
ALTER TABLE `quotation_progress`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quotation_status`
--
ALTER TABLE `quotation_status`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quotation_target`
--
ALTER TABLE `quotation_target`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reminder`
--
ALTER TABLE `reminder`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reminder_type`
--
ALTER TABLE `reminder_type`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `setting_bak1`
--
ALTER TABLE `setting_bak1`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_group_policies`
--
ALTER TABLE `user_group_policies`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_policies`
--
ALTER TABLE `user_policies`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vendor`
--
ALTER TABLE `vendor`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
